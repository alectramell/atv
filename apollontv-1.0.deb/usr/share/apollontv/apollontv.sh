#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

# Default Script..
TOP="stream.sh"

clear

# Source Topic (or Script) of Interest.. 
bash /usr/share/apollontv/$TOP

clear
