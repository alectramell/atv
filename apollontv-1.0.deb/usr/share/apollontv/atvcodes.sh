#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

REQ1=$(which youtube-dl)
REQ2=$(which mplayer)
REQ3=$(which wget)
REQ4=$(which notify-send)
REQ5=$(zenity)

clear

if [ "$REQ1" = "/usr/local/bin/youtube-dl" ]
then
	echo "REQ1=true"
	clear
else
	echo "REQ1=false"
	clear
	sudo apt-get install youtube-dl
	clear
fi

clear

if [ "$REQ2" = "/usr/bin/mplayer" ]
then
	echo "REQ2=true"
	clear
else
	echo "REQ2=false"
	clear
	sudo apt-get install mplayer
	clear
fi

clear

if [ "$REQ3" = "/usr/bin/wget" ]
then
	echo "REQ3=true"
	clear
else
	echo "REQ3=false"
	clear
	sudo apt-get install wget
	clear
fi

clear

if [ "$REQ4" = "/usr/bin/notify-send" ]
then
	echo "REQ4=true"
	clear
else
	echo "REQ4=false"
	clear
	sudo apt-get install notify-send
	clear
fi

clear

if [ "$REQ5" = "/usr/bin/zenity" ]
then
	echo "REQ5=true"
	clear
else
	echo "REQ5=false"
	clear
	sudo apt-get install zenity
	clear
fi

clear

ATVCODE=$(zenity --title="Apollon TV" --entry --text="Enter ATV Code: ")

clear

rm /home/$USERNAME/Desktop/.61706F6C6C6F6E7476.txt
rm /home/$USERNAME/Desktop/.$ATVCODE.txt

clear

sleep 0.5

clear

wget --quiet --no-check-certificate --quiet -O /home/$USERNAME/Desktop/.$ATVCODE.txt -c https://github.com/alectramell/atv/raw/master/$ATVCODE.txt

clear

YTLST=$(cat /home/$USERNAME/Desktop/.$ATVCODE.txt)

clear

youtube() {
	
	mplayer -fs -cookies -cookies-file /home/$USERNAME/Desktop/.atvcookie.txt $(youtube-dl -gf mp4 --cookies /home/$USERNAME/Desktop/.atvcookie.txt "$1")
}

clear

notify-send -t 5000 --urgency="normal" --icon="/usr/share/apollontv/apollontv.svg" "RENDERING VIDEO STREAM" "..This may take a minute.."

tip1() {
	notify-send -t 5000 --urgency="normal" --icon="/usr/share/apollontv/apollontv.svg" "..TIP #1.." "Use [q] to Exit while stream is active.."
}

tip2() {
	notify-send -t 5000 --urgency="normal" --icon="/usr/share/apollontv/apollontv.svg" "..TIP #2.." "Use [SPACE] to Pause video stream.."
}

tip3() {
	notify-send -t 5000 --urgency="normal" --icon="/usr/share/apollontv/apollontv.svg" "..TIP #3.." "Use [f] to Leave Full Screen.."
}

MINTS=$(date +%S)

if [ "$MINTS" = "30" ]
then
	tip2
elif [ "$MINTS" -gt "30" ]
then
	tip3
elif [ "$MINTS" -lt "30" ]
then
	tip1
else
	tip1
fi

youtube "$YTLST"

sleep 0.5

killall mplayer
killall youtube-dl

sleep 0.5

clear

ADAY=$(date +%A)

clear

if [ "$ADAY" = "Monday" ]
then
	notify-send -t 10000 --urgency="normal" --icon="/usr/share/apollontv/facebook.svg" "Hey! Like Us on Facebook!" "http://www.facebook.com/apollondma"

	notify-send -t 10000 --urgency="normal" --icon="/usr/share/apollontv/youtube.svg" "Subscibe to our YouTube Channel!" "https://www.youtube.com/playlist?list=PLGjV_oR4IPN8wlQMRMBOxDkYGppLpPXMn"

elif [ "$ADAY" = "Wednesday" ]
then
	notify-send -t 10000 --urgency="normal" --icon="/usr/share/apollontv/facebook.svg" "Like Us on Facebook!" "http://www.facebook.com/apollondma"

	notify-send -t 10000 --urgency="normal" --icon="/usr/share/apollontv/youtube.svg" "Subscibe to our YouTube Channel!" "https://www.youtube.com/playlist?list=PLGjV_oR4IPN8wlQMRMBOxDkYGppLpPXMn"

elif [ "$ADAY" = "Thursday" ]
then

	notify-send -t 10000 --urgency="normal" --icon="/usr/share/apollontv/facebook.svg" "Like Us on Facebook!" "http://www.facebook.com/apollondma"

	notify-send -t 10000 --urgency="normal" --icon="/usr/share/apollontv/youtube.svg" "Subscibe to our YouTube Channel!" "https://www.youtube.com/playlist?list=PLGjV_oR4IPN8wlQMRMBOxDkYGppLpPXMn"

elif [ "$ADAY" = "Friday" ]
then
	notify-send -t 10000 --urgency="normal" --icon="/usr/share/apollontv/youtube.svg" "Subscibe to our YouTube Channel!" "https://www.youtube.com/playlist?list=PLGjV_oR4IPN8wlQMRMBOxDkYGppLpPXMn"

	notify-send -t 10000 --urgency="normal" --icon="/usr/share/apollontv/facebook.svg" "..and Like Us on Facebook!" "http://www.facebook.com/apollondma"

elif [ "$ADAY" = "Saturday" ]
then
	notify-send -t 10000 --urgency="normal" --icon="/usr/share/apollontv/youtube.svg" "Subscibe to our YouTube Channel!" "https://www.youtube.com/playlist?list=PLGjV_oR4IPN8wlQMRMBOxDkYGppLpPXMn"

else
	echo "aday=false"
fi

clear
